package controller_servlets;

import dao.ClienteDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Cliente;

//NÃO ESTAVA FUNCIOANDO
@WebServlet(urlPatterns = "/busca_clientes")
public class BuscaClientes_Servlets extends HttpServlet {

    public BuscaClientes_Servlets() {
        System.err.println("CRIOU BuscaClientes_Servlets: " + this);
    }

    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.
        System.err.println("INICIALIZOU BuscaClientes_Servlets " + this);

    }

    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.
        System.err.println("DESTRUIU BuscaClientes_Servlets: " + this);

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        System.out.println("Chamou doGet do Servlet ....");

        PrintWriter resposta = resp.getWriter();
        resposta.println("<html><body>");
        /*UsuarioDAO uDao = new UsuarioDAO();        
      ArrayList<Usuario> usuarios =  uDao.getUsuarios();        
      for(int i = 0; i < usuarios.size(); i++ ){
          Usuario u = usuarios.get(i); 
          u.getNome();
      }  */
        resposta.println("<ul>");
        for (Cliente u : new ClienteDAO().getCliente()) {
            resposta.println("<li>" + u.getEmailCli() + "</li>");
        }
        resposta.println("</ul>");

        resposta.println("<h1>Cliente CONSULTADO</h1>");
//        trabalhando com request da url

        String emailCli = req.getParameter("emailCli");
        String senhaCli = req.getParameter("senhaCli");
        Cliente c = new ClienteDAO().read(emailCli, senhaCli);

        try {
//            Cliente cliente = new ClienteDAO().read(Integer.parseInt(codigo));
            resposta.println("<h4>Nome:" + c.getEmailCli() + "</h4>");
        } catch (NumberFormatException ex) {
            resposta.println("<h3>erro</h3>");
        } catch (NullPointerException ex2) {
            resposta.println("<h3>erro</h3>");
        } catch (Exception e) {
            resposta.println("<h3>erro</h3>");
//        }

            resposta.println("</body></html>");
        }
    }
}