
package controller_servlets;

import dao.ClienteDAO;
import dao.LoginClienteDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Cliente;
@WebServlet(urlPatterns = "/loginC")
public class LoginCliente_Servlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        String emailCli = req.getParameter("emailCli");
        String senhaCli = req.getParameter("senhaCli");
        
        System.err.println(emailCli + " " + senhaCli);
        
        RequestDispatcher disp;
        
        Cliente autenticado = new LoginClienteDAO().autenticar(emailCli, senhaCli);
        
        if(autenticado.getId() != 0){                       
            
           // Chave que ficará aberta em toda a sessão, onde posso pegar tudo que for passado através da sessão
            HttpSession sessao = req.getSession();
            sessao.setAttribute("usuarioLogado", autenticado);
            
            disp = req.getRequestDispatcher("Livros.jsp");//depois de verificar o cliente vai para a página de vender os livros 
            disp.forward(req, resp);
            
        } else {            
            req.setAttribute("mensagem_erro", "Senha ou email incorreto!");
            disp = req.getRequestDispatcher("index.jsp");//continua onde deve estar
            disp.forward(req, resp);
        }
                
    }        
}
