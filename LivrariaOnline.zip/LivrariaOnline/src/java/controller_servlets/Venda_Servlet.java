/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller_servlets;

import dao.VendaDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Cliente;

@WebServlet(urlPatterns = "/venda")
public class Venda_Servlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        HttpSession sessao = req.getSession();
        Cliente cli = new Cliente();
        
        cli=(Cliente) sessao.getAttribute("usuarioLogado");
        
        String id = req.getParameter("codLivro");
        RequestDispatcher disp;
        boolean ret =new VendaDAO().create(cli.getId(), Integer.parseInt(id));
        
        if(ret){
            req.setAttribute("mensagem", "Compra feita");
            disp = req.getRequestDispatcher("Livros.jsp");
            disp.forward(req, resp);
            //mensagem de ok e retorna pra pagina de venda
        }else{
            //mensagem de erro e retorna para pag de venda
            req.setAttribute("mensagem", "Erro na compra");
            disp = req.getRequestDispatcher("Livros.jsp");
            disp.forward(req, resp);
        }

    }
    
    
    
}
