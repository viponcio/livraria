
package controller_servlets;

import static com.sun.corba.se.spi.presentation.rmi.StubAdapter.request;
import static com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type.Int;
import dao.LivroDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Livros;
@WebServlet(urlPatterns = "cadastrar_livro")
public class Cadastra_Livro_Servlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("Chamou GET ....");
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("método post requisitado ....");
        
        PrintWriter resposta = resp.getWriter();
        
        Integer codLivro = Integer.parseInt(req.getParameter("codLivro"));
        String livro = req.getParameter("livro");
        String editora = req.getParameter("editora");
        String autor = req.getParameter("autor");
        float preco = Float.parseFloat(req.getParameter("preco"));
        
        Livros livros = new Livros(codLivro,livro, editora, autor,preco);
        
        boolean retorno = new LivroDAO().create(livros);
        if(retorno){

            req.setAttribute("nome_livro", livro);
            RequestDispatcher disp = req.getRequestDispatcher("cadastrarLivro.jsp");
            disp.forward(req, resp);
            //resp.sendRedirect(req.getContextPath()+"/cadastrarLivro.jsp");
            
        }else{            
resposta.println("<html><body><strong>ERRO</strong></body></html>");
        }
    }
}
