package controller_servlets;

import dao.ClienteDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Cliente;
@WebServlet(urlPatterns = "/cadastraCli")
public class Cadastra_Cliente_Servlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("Chamou GET ....");
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("método post requisitado ....");
        
        PrintWriter resposta = resp.getWriter();
        
        String emailCli = req.getParameter("emailCli");
        String senhaCli = req.getParameter("senhaCli");
        Cliente cliente = new Cliente(emailCli, senhaCli);
        
        boolean retorno = new ClienteDAO().create(cliente);
        
        if(retorno){
            req.setAttribute("emailCli", emailCli);
            RequestDispatcher disp = req.getRequestDispatcher("Livros.jsp");
            disp.forward(req, resp);
            //resp.sendRedirect(req.getContextPath()+"Livros.jsp");
            
        }else{            
            resposta.println("<html><body><strong>ERRO</strong></body></html>");
        }
    }

}
