//meu
package controller_servlets;

import dao.FuncionarioDAO;
import dao.LoginFuncionarioDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Funcionario;
@WebServlet(urlPatterns = "/loginF")
public class loginFuncionario_Servlet extends HttpServlet {
//NÃO ESTA FUNCIONANDO
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        String emailfunc = req.getParameter("emailfunc");
        String senhafunc = req.getParameter("senhafunc");
        
        System.err.println(emailfunc + " " + senhafunc);
        
        RequestDispatcher disp;
        
        Funcionario autenticado = new LoginFuncionarioDAO().autenticar(emailfunc, senhafunc);
        
        if(autenticado.getId() != 0){       
           // Chave que ficará aberta em toda a sessão, onde posso pegar tudo que for passado através da sessão
            HttpSession sessao = req.getSession();
            sessao.setAttribute("funcionarioLogado", autenticado);
            
            disp = req.getRequestDispatcher("/WEB-INF/views/sucesso.jsp");//depois de cadastrar o funcionario vai para a página de cadastrar os livros 
            disp.forward(req, resp);
            
        } else {            
            req.setAttribute("mensagem_erro", "Senha ou email incorreto!");
            disp = req.getRequestDispatcher("Livros.jsp");//continua onde deve estar
            disp.forward(req, resp);
        }
                
    }        
}
