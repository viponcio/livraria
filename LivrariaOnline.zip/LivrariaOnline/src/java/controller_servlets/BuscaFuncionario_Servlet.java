package controller_servlets;

import dao.FuncionarioDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Funcionario;

@WebServlet(urlPatterns = "/busca_funcionario")
public class BuscaFuncionario_Servlet extends HttpServlet {

    public BuscaFuncionario_Servlet() {
        System.err.println("CRIOU busca_funcionario " + this);
    }

    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.
        System.err.println("INICIALIZOU BuscaFuncionario_Servlet: " + this);

    }

    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.
        System.err.println("DESTRUIU BuscaFuncionario_Servlet: " + this);

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        System.out.println("Chamou doGet do Servlet ....");

        PrintWriter resposta = resp.getWriter();
        resposta.println("<html><body>");
        resposta.println("<strong>UsuÃ¡rios cadastrados!</strong>");

        FuncionarioDAO fDao = new FuncionarioDAO();
        ArrayList<Funcionario> funcionarios = fDao.getFuncionarios();
        for (int i = 0; i < funcionarios.size(); i++) {
            Funcionario f = funcionarios.get(i);
            f.getEmailFunc();
        }
//        resposta.println("<ul>");
//        for (Funcionario f : new FuncionarioDAO().getFuncionarios()) {
//            System.out.println("oiii");
//            resposta.println("<li>" + f.getEmailFunc() + "</li>");
//        }
//        resposta.println("</ul>");

        resposta.println("<h1>USUÃRIO CONSULTADO</h1>");
        //trabalhando com request da url

        String codigo = req.getParameter("codigo");

        try {
            Funcionario funcionario = new FuncionarioDAO().read(Integer.parseInt(codigo));
            resposta.println("<h4>Nome:" + funcionario.getEmailFunc() + "</h4>");
        } catch (NumberFormatException ex) {
            resposta.println("<h3>erro</h3>");
        } catch (NullPointerException ex2) {
            resposta.println("<h3>erro</h3>");
        } catch (Exception e) {
            resposta.println("<h3>erro</h3>");
        }

        resposta.println("</body></html>");
    }
}
