/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller_servlets;

import dao.FuncionarioDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Funcionario;
@WebServlet(urlPatterns = "/cadastrar_funcionario")
public class Cadastra_Funcionario_Servlet extends HttpServlet {

     @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("Chamou GET ....");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("método post requisitado ....");
        
        PrintWriter resposta = resp.getWriter();
        
        String emailFunc = req.getParameter("emailFunc");
        String senhaFunc = req.getParameter("senhaFunc");
        Funcionario funcionario = new Funcionario(emailFunc,senhaFunc);
        
        boolean retorno = new FuncionarioDAO().create(funcionario);
        
        if(retorno){

            req.setAttribute("nome_usuario", emailFunc);
 RequestDispatcher disp 
         = req.getRequestDispatcher("cadastrarLivro.jsp");
 disp.forward(req, resp);
           // resp.sendRedirect(req.getContextPath()+"/sucesso.html");
            
        }else{            
resposta.println("<html><body><strong>ERRO</strong></body></html>");
        }
    }

}
