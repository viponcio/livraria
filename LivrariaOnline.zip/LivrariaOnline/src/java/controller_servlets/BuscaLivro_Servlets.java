
package controller_servlets;

import dao.LivroDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Livros;
@WebServlet(urlPatterns = "/busca_livros")
public class BuscaLivro_Servlets extends HttpServlet {
    public class BuscaClientes_Servlets extends HttpServlet {
    public BuscaClientes_Servlets() {
        System.err.println("CRIOU busca_livros: " + this);
    }

    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.
        System.err.println("INICIALIZOU busca_livros " + this);

    }

    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.
        System.err.println("DESTRUIU busca_livros: " + this);

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        System.out.println("Chamou doGet do Servlet ....");

        PrintWriter resposta = resp.getWriter();
        resposta.println("<html><body>");
        resposta.println("<strong>Livros cadastrados!</strong>");

        /*UsuarioDAO uDao = new UsuarioDAO();        
      ArrayList<Usuario> usuarios =  uDao.getUsuarios();        
      for(int i = 0; i < usuarios.size(); i++ ){
          Usuario u = usuarios.get(i); 
          u.getNome();
      }  */
        resposta.println("<ul>");
        for (Livros l : new LivroDAO().getLivros()) {
            resposta.println("<li>" + l.getAutor()+ "</li>");//talvez colocar o nome do livro,editora aqui
            resposta.println("<li>" + l.getEditora()+ "</li>");
            resposta.println("<li>" + l.getLivro()+ "</li>");
        }
        resposta.println("</ul>");
        resposta.println("<h1>Livro CONSULTADO</h1>");
        //trabalhando com request da url

      String  codigo = req.getParameter("cod");

        try {
            Livros livro = new LivroDAO().read(Integer.parseInt(codigo));
            resposta.println("<h4>Nome:" + livro.getAutor()+ "</h4>");
        } catch (NumberFormatException ex) {
            resposta.println("<h3>Digite NÃºmeros</h3>");
        } catch (NullPointerException ex2) {
            resposta.println("<h3>Codigo invÃ¡lido</h3>");
        } catch (Exception e) {
            resposta.println("<h3>Q locura home!</h3>");
        }

        resposta.println("</body></html>");
    }
    }
}
