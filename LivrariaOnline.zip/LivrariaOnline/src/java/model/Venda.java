
package model;

public class Venda {
    private int codigovenda;
    private Cliente cliente  ;
    private Livros livro;
    
    
    public Venda() {
    }

    public int getCodigovenda() {
        return codigovenda;
    }

    public void setCodigovenda(int codigovenda) {
        this.codigovenda = codigovenda;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Livros getLivro() {
        return livro;
    }

    public void setLivro(Livros livro) {
        this.livro = livro;
    }
    
    
    
    
    
}
