
package model;
public class Cliente {
    private int id;
    private String emailCli;
    private String senhaCli;

    public Cliente(String emailCli, String senhaCli) {
        this.emailCli = emailCli;
        this.senhaCli = senhaCli;
    }

    public Cliente() {
        
    }
    
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmailCli() {
        return emailCli;
    }

    public void setEmailCli(String emailCli) {
        this.emailCli = emailCli;
    }

    public String getSenhaCli() {
        return senhaCli;
    }

    public void setSenhaCli(String senhaCli) {
        this.senhaCli = senhaCli;
    }

   
    
    
}
