
package model;
public class Funcionario {
    private int id;
    private String emailFunc ;
    private String senhaFunc;

    public Funcionario(String emailFunc, String senhaFunc) {
        this.emailFunc = emailFunc;
        this.senhaFunc = senhaFunc;
    }
    
    public Funcionario(){
        
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmailFunc() {
        return emailFunc;
    }

    public void setEmailFunc(String emailFunc) {
        this.emailFunc = emailFunc;
    }

    public String getSenhaFunc() {
        return senhaFunc;
    }

    public void setSenhaFunc(String senhaFunc) {
        this.senhaFunc = senhaFunc;
    }

    public void setId(String id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
