
package model;
public class Livros {
    private int codLivro;
    private String livro;
    private String editora;
    private String autor;
    private float preco;

    public Livros(int codLivro, String livro, String editora, String autor, float preco) {
        this.codLivro = codLivro;
        this.livro = livro;
        this.editora = editora;
        this.autor = autor;
        this.preco = preco;
    }

    public Livros(){
        
    }

    public int getCodLivro() {
        return codLivro;
    }

    public void setCodLivro(int codLivro) {
        this.codLivro = codLivro;
    }
    
    public String getLivro() {
        return livro;
    }

    public void setLivro(String livro) {
        this.livro = livro;
    }

    public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }
    
}
