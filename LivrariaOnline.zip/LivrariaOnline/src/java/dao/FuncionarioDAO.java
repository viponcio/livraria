package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import model.Funcionario;
//TUDO FUNCIONANDO
public class FuncionarioDAO {
    public static void main(String args[]){
        
       /* Funcionario f = new Funcionario();
        f.setEmailFunc("email novo");
        f.setSenhaFunc("789");
        f.setId(1);
        new FuncionarioDAO().update(f);*/

       // boolean deletado = new FuncionarioDAO().delete(2);
        
//        Funcionario f=new FuncionarioDAO().read(2);
//        System.out.println("email:"+f.getEmailFunc());
    }
    public boolean create(Funcionario f){
        
        try(Connection conn=new ConectaDB_Postgres().getConexao()){
            String sql=" INSERT INTO funcionario(emailFunc,senhaFunc) "
                    + " VALUES (?, ?)";
            PreparedStatement pre=conn.prepareStatement(sql);
            pre.setString(1, f.getEmailFunc());
            pre.setString(2, f.getSenhaFunc());
            if(pre.executeUpdate()>0){
                return true;
            }
        }catch(SQLException e){
            e.printStackTrace();
        } 
        return false;
    }
    
    public Funcionario read(int id){
        try(Connection conn=new ConectaDB_Postgres().getConexao()){
            String sql=" SELECT * "
                    + " FROM funcionario "
                    + " WHERE id=?; ";
            PreparedStatement pre=conn.prepareStatement(sql);
            pre.setInt(1, id);
            ResultSet rs=pre.executeQuery();
            
            while(rs.next()){
                Funcionario f = new Funcionario();
                f.setId(id);
                f.setEmailFunc(rs.getString("emailFunc"));
                f.setSenhaFunc(rs.getString("senhaFunc"));
                return f;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return null;
    }//TROCAR ONDE ESTA ESCRITO EMAIL E SENHA POR EMAILFUNC SENHAFUNC
    public Funcionario read(String emailfunc, String senhafunc) {
        try(Connection conn = new ConectaDB_Postgres().getConexao()){
            String sql = "SELECT * FROM funcionario"
                        + " WHERE emailfunc = ? AND senhafunc=?";
            PreparedStatement pre = conn.prepareStatement(sql);
            pre.setString(1, emailfunc);
            pre.setString(2, senhafunc );
            ResultSet rs = pre.executeQuery();
            while(rs.next()){
                Funcionario f = new Funcionario();
                f.setEmailFunc(rs.getString("emailfunc"));
                f.setSenhaFunc(rs.getString("senhafunc"));
                return f;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }       
        return null;
    }
    
    public boolean update(Funcionario funcionario){
        try(Connection conn= new ConectaDB_Postgres().getConexao()){
            String sql=" UPDATE funcionario "
                    + " SET emailFunc=? , senhaFunc=? "
                    + " WHERE id=?; ";
            PreparedStatement pre=conn.prepareStatement(sql);
            pre.setString(1, funcionario.getEmailFunc());
            pre.setString(2, funcionario.getSenhaFunc());
            pre.setInt(3, funcionario.getId());
            if(pre.executeUpdate() > 0){
                return true;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return false;
    }
    public boolean delete(int id){
        try(Connection conn = new ConectaDB_Postgres().getConexao()){
            String sql = " DELETE FROM funcionario "
                    + "WHERE id=?";
            PreparedStatement pre=conn.prepareCall(sql);
            pre.setInt(1, id);
            if(pre.executeUpdate() > 0){
                return true;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return false;
    }
    
    public ArrayList<Funcionario> getFuncionarios(){
        ArrayList<Funcionario> funcionarios= new ArrayList<>();
        try(Connection conn= new ConectaDB_Postgres().getConexao()){
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery("SELECT * FROM funcionario");
            while(rs.next()){
                Funcionario fc = new Funcionario();
                fc.setId(rs.getInt("id"));
                fc.setEmailFunc(rs.getString("emailFunc"));
                fc.setSenhaFunc(rs.getString("senha"));
                funcionarios.add(fc);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return funcionarios;
    }
    
}
