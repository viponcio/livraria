package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import model.Venda;

public class VendaDAO {
    
    private boolean retorno=false;
    private String sql="";
    private PreparedStatement pre;
    private ResultSet rs;
    
    /**
     * 
     * @param id
     * @param codLivro
     * @return 
     */
    public boolean create(int id,int codLivro){
        try(Connection conn = new ConectaDB_Postgres().getConexao() ) {
            sql="INSERT INTO venda (id,codLivro)"
                    + "VALUES (?,?);";
            pre=conn.prepareStatement(sql);
            
            pre.setInt(1, id);
            pre.setInt(2, codLivro);
            pre.execute();
            retorno = true;        
        } catch (Exception e) {
            e.printStackTrace();
        }
        return retorno;
    }
}
