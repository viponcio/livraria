/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Funcionario;

/**
 *
 * @author vitor
 */
public class LoginFuncionarioDAO {
    public Funcionario autenticar(String emailfunc, String senhafunc){
        Funcionario f=new Funcionario();
        try(Connection conn =new ConectaDB_Postgres().getConexao() ){
           
           String sql = " SELECT * FROM funcionario "
                   + " WHERE emailfunc = ? AND senhafunc = ?";
           PreparedStatement pStmt = conn.prepareStatement(sql);
           pStmt.setString(1, emailfunc);
           pStmt.setString(2, senhafunc);
           ResultSet rs = pStmt.executeQuery();
           while(rs.next()){
               f.setEmailFunc(rs.getString("emailfunc"));
               f.setId("id");
               f.setSenhaFunc(rs.getString("senhafunc"));
           }
           
       }catch(SQLException e){
           e.printStackTrace();
       }
        
        return f;
    }
}
