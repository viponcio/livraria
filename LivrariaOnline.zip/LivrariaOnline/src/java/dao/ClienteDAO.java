package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import model.Cliente;
//TUDO FUNCIONANDO
public class ClienteDAO {
    public static void main(String args[]) {
//       Cliente cc= new Cliente();
//       new ClienteDAO().create("@ail","6962s");
//
//       Cliente c=new ClienteDAO().read(1);
//        System.out.println("email:"+c.getEmailCli());
            
//        Cliente cc= new Cliente();
//        cc.setEmailCli("luludwes");
//        cc.setSenhaCli("78sds");
//        cc.setId(2);
//        new ClienteDAO().update(cc);

//        ISSO DEVE SER IMPLEMENTADO NO HTML
//        boolean deletado =new ClienteDAO().delete(4);

          //REFAZER A ARRAY LIST,dia 10/10 NÃO SEI PQ EU ESCREVI ISSO  
    }
    
    public int create(String emailCli,String senhaCli){
        try (Connection conn = new ConectaDB_Postgres().getConexao()) {

            String sql = " INSERT INTO cliente(emailCli, senhaCli) "
                    + " VALUES(?, ?);";
            PreparedStatement pre = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            pre.setString(1, emailCli);
            pre.setString(2, senhaCli);
            pre.execute();
            ResultSet rs=pre.getGeneratedKeys();
            rs.next();
            if(rs.getInt(1)>0){
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
        
    }
    
    public boolean create(Cliente cliente) {

        try (Connection conn = new ConectaDB_Postgres().getConexao()) {

            String sql = " INSERT INTO Cliente(emailCli, senhaCli) "
                    + " VALUES(?, ?);";
            PreparedStatement pre = conn.prepareStatement(sql);
            pre.setString(1, cliente.getEmailCli());
            pre.setString(2, cliente.getSenhaCli());
            if (pre.executeUpdate() > 0) {
                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
    public Cliente read(int id) {
        try (Connection conn = new ConectaDB_Postgres().getConexao()) {
            String sql = "SELECT * FROM cliente"
                    + " WHERE id = ?";
            PreparedStatement pre = conn.prepareStatement(sql);
            pre.setInt(1, id);
            ResultSet rs = pre.executeQuery();
            while (rs.next()) {
                Cliente c = new Cliente();
                c.setEmailCli(rs.getString("email"));
                c.setSenhaCli(rs.getString("senha"));
                return c;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public Cliente read(String emailCli, String senhaCli) {
        try(Connection conn = new ConectaDB_Postgres().getConexao()){
            String sql = "SELECT * FROM Cliente"
                        + " WHERE emailCli = ? AND senhaCli=?";
            PreparedStatement pre = conn.prepareStatement(sql);
            pre.setString(1, emailCli);
            pre.setString(2, senhaCli );
            ResultSet rs = pre.executeQuery();
            while(rs.next()){
                Cliente u = new Cliente();
                u.setEmailCli(rs.getString("emailCli"));
                u.setSenhaCli(rs.getString("senhaCli"));
                return u;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }       
        return null;
    }
    
    public boolean update(Cliente cliente) {
        
        try(Connection conn = new ConectaDB_Postgres().getConexao()){
            String sql = " UPDATE cliente"
                         +" SET emailCli = ?, senhaCLi =?"
                         +" WHERE id = ?";
            PreparedStatement pre = conn.prepareStatement(sql);
            pre.setString(1, cliente.getEmailCli());
            pre.setString(2, cliente.getSenhaCli());
            pre.setInt(3, cliente.getId());
            if(pre.executeUpdate() > 0){
                return true;
            }          
        }catch(SQLException e){
          e.printStackTrace();
        }

        return false;
    }
    public boolean delete(int id) {

    try(Connection conn = new ConectaDB_Postgres().getConexao()){
        String sql = " DELETE FROM Cliente"
                    +" WHERE id = ?";
        PreparedStatement pre = conn.prepareStatement(sql);
        pre.setInt(1, id);
            if(pre.executeUpdate() > 0){
                return true;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }

        return false;
    }
    
    public ArrayList<Cliente> getCliente() {
        ArrayList<Cliente> clientes = new ArrayList<>();
        // Connection conn = new ConectaDB_Postgres().getConexao();
        try (Connection conn = new ConectaDB_Postgres().getConexao()) {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT *  FROM Cliente");
            while (rs.next()) {
                Cliente c = new Cliente();
                c.setId(rs.getInt("id"));
                c.setEmailCli(rs.getString("email"));
                c.setSenhaCli(rs.getString("senha"));
                clientes.add(c);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return clientes;
    }
}
