
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Cliente;

public class LoginClienteDAO {
     public Cliente autenticar(String emailCli, String senhaCli){//talvez trocar aqui
       Cliente cli=new Cliente();
       try(Connection conn =new ConectaDB_Postgres().getConexao() ){
           
           String sql = " SELECT * FROM cliente "
                   + " WHERE senhaCli = ? AND emailCli = ?";
           PreparedStatement pStmt = conn.prepareStatement(sql);
           pStmt.setString(1, senhaCli);// e trocar aqui tamb
           pStmt.setString(2, emailCli);
           
           ResultSet rs = pStmt.executeQuery();
           while(rs.next()){
               cli.setEmailCli(rs.getString("emailcli"));
               cli.setId(rs.getInt("id"));
               cli.setSenhaCli(rs.getString("senhacli"));
               
           }
           
       }catch(SQLException e){
           e.printStackTrace();
       }
        return cli;
      
    }
}
