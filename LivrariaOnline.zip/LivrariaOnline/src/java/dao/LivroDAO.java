package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import model.Livros;
//ALL WORKING
public class LivroDAO {
   public static void main(String args[]){
//        Livros ll=new Livros();
//        new LivroDAO().create("nome DO livro", "nome DA editora", "autor DDnomes", 705);
//        ll.setAutor("lala");
//        ll.setEditora("faber");
//        ll.setLivro("menina");
//        ll.setCodLivro(3);
//        new LivroDAO().update(ll);
   
//        new LivroDAO().delete(2);
//        Livros l=new LivroDAO().read(1);
//        System.out.println("nome do livro:"+l.getLivro());
        
        
    }
    
    public int create(int codLivro,String livro,String editora,String autor,float preco){
        try(Connection conn = new ConectaDB_Postgres().getConexao() ) {
            String sql="INSERT INTO livros (codLivro,livro,editora,autor,preco)"
                    + "VALUES (?,?,?,?,?);";
            PreparedStatement pre=conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
            pre.setInt(1, codLivro);
            pre.setString(2, livro);
            pre.setString(3, editora);
            pre.setString(4, autor);
            pre.setFloat(5, preco);//é double
            pre.execute();
            ResultSet rs = pre.getGeneratedKeys();
            rs.next();
            if(rs.getInt(1) > 0){
                return rs.getInt(1);
            }        
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
    public boolean create(Livros l){
        
        try(Connection conn=new ConectaDB_Postgres().getConexao()){
            String sql=" INSERT INTO livros(codLivro,livro,editora,autor,preco) "
                    + " VALUES (? , ? , ? , ? , ?)";
            PreparedStatement pre=conn.prepareStatement(sql);
            pre.setInt(1, l.getCodLivro());
            pre.setString(2, l.getLivro());
            pre.setString(3, l.getEditora());
            pre.setString(4, l.getAutor());
            pre.setFloat(5, l.getPreco());
            if(pre.executeUpdate()>0){
                return true;
            }
        }catch(SQLException e){
            e.printStackTrace();
        } 
        return false;
    }
    public Livros read(int codLivro){
        try (Connection conn=new ConectaDB_Postgres().getConexao()){
            String sql="SELECT * FROM Livros"
                    + " WHERE codLivro=?;";
            PreparedStatement pre = conn.prepareStatement(sql);
            pre.setInt(1, codLivro);
            ResultSet rs = pre.executeQuery();
            while(rs.next()){
                Livros l = new Livros();
                l.setAutor(rs.getString("autor"));
                l.setEditora(rs.getString("editora"));
                l.setLivro(rs.getString("livro"));
                l.setPreco(rs.getFloat("preco"));
                return l;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    public boolean update(Livros livro){
        try (Connection conn = new ConectaDB_Postgres().getConexao()){
            String sql="UPDATE livros "
                    + " SET livro = ?, editora = ?, autor = ?, preco = ? " 
                    + " WHERE codlivro=? ;";
            PreparedStatement pre=conn.prepareStatement(sql);
             pre.setString(1, livro.getLivro());
            pre.setString(2, livro.getEditora());
            pre.setString(3, livro.getAutor());
            pre.setFloat(4, livro.getPreco());
            pre.setInt(5,livro.getCodLivro());
            
            if(pre.executeUpdate()>0){
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean delete(int codLivro){
        try (Connection conn = new ConectaDB_Postgres().getConexao()){
            String sql = "DELETE FROM livros "
                    + "WHERE codLivro=?;";
            PreparedStatement pre=conn.prepareStatement(sql);
            pre.setInt(1, codLivro);
                if(pre.executeUpdate() > 0){
                    return true;
                }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public ArrayList<Livros> getLivros(){
        ArrayList<Livros> livro=new ArrayList<>();
        try (Connection conn= new ConectaDB_Postgres().getConexao()){
            Statement st=conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM Livros");
            
            while(rs.next()){
                Livros l= new Livros();
                l.setCodLivro(rs.getInt("codLivro"));
                l.setLivro(rs.getString("livro"));
                l.setAutor(rs.getString("autor"));
                l.setEditora(rs.getString("editora"));
                l.setPreco(rs.getFloat("preco"));
                livro.add(l);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return livro;
    }
    
}
